Application public content
