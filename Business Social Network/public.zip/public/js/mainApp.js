var mainApp = angular.module('mainApp', [ 'ngRoute']);
mainApp.config(['$routeProvider',
                  function($routeProvider) {

                  }
               ]
);
